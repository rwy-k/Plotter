﻿
#include<sstream>
#include <stdio.h>
#include <math.h>
#include <iostream>
#include <string.h>
#include <conio.h>
using namespace std;
const char number = '8';
const char print = ';';
const char name = '!';

class Token { // î÷åíü ïðîñòîé òèï, îïðåäåëåííûé ïîëüçîâàòåëåì
public:
	char kind;
	double value;
	string name;
	Token(char ch) :kind(ch), value(0) { }
	Token(char ch, double val) :kind(ch), value(val) { }
	Token(char ch, string n) :kind(ch), name(n) {}
};

class Token_stream {
private:
	bool full;
	Token buffer;
	stringstream ss;
public:
	Token_stream() :full(false), buffer(0) {}
	void Set(string f) { ss << f; }
	Token get() {
		if (full) {
			full = false;
			return buffer;
		}
		char ch;
		ss >> ch;

		switch (ch) {
		case print:
		case '(':
		case ')':
		case '+':
		case '-':
		case '*':
		case '/':
		case '%':
		{return Token(ch); }
		case '.':
		case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': {
			ss.putback(ch); // âîçâðàùàåì ïåðâóþ öèôðó, ÷òîáû ñ÷èòàòü åå çàíîâî, óæå â ÷èñëå
			double val;
			ss >> val;
			return Token(number, val);
			break;
		}
		default:
			if (isalpha(ch)) {
				if (ch == 'x') return Token('x');
				string s;
				s += ch;
				while (ss.get(ch) && isalpha(ch))
					s += ch; ss.putback(ch);
				ss.get(ch);
				if (s != "sin" && s != "cos" && s!="tan" && s!="ctan") {
					cout << "ERROR: it is not a function ";
					_getch();  exit;
				} else
					if (ch != '(') {
						cout << "ERROR: '()' expected "; _getch(); exit;
					} 
				ss.putback(ch); 
				return Token(name, s);
			}
			cout << ("ERRRORR"); _getch(); exit;
		}
	}
	void putback(Token t) {
		if (full) cout << ("putback() to full buffer");
		buffer = t;
		full = true;
	}
	void ignore(char c) {
		if (full && c == buffer.kind) {
			full = false;
			return;
		}
		full = false;
		char ch = 0;
		while (ss >> ch) if (ch == c) return;
	}
};




