
#include<iostream>
#include<sstream>
#include<cmath>
#include<string>
#include <conio.h>
using namespace std;
double expression(double y);
double term(double y);
double primary(double y);
double calculate(double y);

#include "TOKENSTREAM.h"
Token_stream ts;

double expression(double y) { // +,-
	double left = term(y);
	Token t = ts.get();
	while (true) {
		switch (t.kind) {
		case '+': {
			left += term(y);
			t = ts.get();
			break;
		}
		case '-': {
			left -= term(y);
			t = ts.get();
			break;
		}
		default:
			ts.putback(t);
			return left;
		}
	}
}
double term(double y) { //*,/
	double left = primary(y);
	Token t = ts.get();
	while (true) {
		switch (t.kind) {
		case '*': {
			left *= primary(y);
			t = ts.get();
			break;
		}
		case '/': {
			double d = primary(y);
			left /= d;
			t = ts.get();
			break;
		}
		case '%': {
			double d = primary(y);
			int i1 = (int)left;
			int i2 = (int)d;
			left = i1 % i2;
			t = ts.get();
			break;
		}
		default:
			ts.putback(t);
			return left;
		}
	}
}
double primary(double y) {//(1234)
	Token t = ts.get();
	switch (t.kind) {
	case '(': {
		double d = expression(y);
		t = ts.get();
		if (t.kind != ')') {
			cout << ("')'expected");
			_getch(); exit;
		}
		return d;
	}
	case number: return t.value;
	case 'x': return y;
	case '-': return -primary(y);
	case '+': return primary(y);
	case name: {
		double d = expression(y);
		t = ts.get();
		if (t.name == "sin")
		return (sin(d)); 
		if (t.name == "cos")
			return (cos(d));
	}
	default: {
		cout << ("Expression is expected");
		_getch(); exit; }
	}
}
double calculate(double y)  {
		Token t = ts.get();
		while (t.kind == print) t = ts.get();
		ts.putback(t);
		return expression(y);
	}
	


